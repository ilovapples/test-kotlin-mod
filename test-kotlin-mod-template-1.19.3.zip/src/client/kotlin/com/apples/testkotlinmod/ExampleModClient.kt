package com.apples.testkotlinmod

import net.fabricmc.api.ClientModInitializer

object ExampleModClient : ClientModInitializer {
    override fun onInitializeClient() {
        // This entrypoint is suitable for setting up client-specific logic, such as rendering.
    }
}